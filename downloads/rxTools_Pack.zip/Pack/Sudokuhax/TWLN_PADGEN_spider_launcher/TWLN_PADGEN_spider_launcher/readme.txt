TWLN PADGEN

Overview:
-tool for dumping a twln partition xorpad and most of the tools needed to modify it and inject back to NAND
-decrypt9 is also an option although I don't know if their xorpads are compatible with this kit.

Dependencies: 
-a way to mount and modify fat archives. OSFmount and WinImage come to mind.
-Gateway firmware to dump your nand and restore it. (recommended)
-4.1 - 9.2 old 3ds
-python 2.7
-Windows

1. run the MsetForBoss.dat or Launcher.dat (with gateway GO online launcher or equivalent) to extract a twln.xorpad to your SD.
2. place twln.xorpad in the InjectionTools folder
3. Dump your NAND.bin with Gateway firmware and place it in InjectionTools folder
4. Run DumpAndDecryptTWLN.bat
5. Modify (with common sense) twln.img with osfmount or winimage as it is a fat12 archive
6. Save twln.img as twln.img and run EncryptAndInjectTWLN.bat to inject it back to the NAND.bin.
7. Strongly recommended to test your NAND.bin as an Emunand before writing it to sysnand! 

WARNING *If any terms or techniques here confuse you, don't do any of this.* This is not idiot-proof and not for beginners.
This is NAND (system firmware) modding and it is dangerous to stable 3ds operation. You agree to be responsible for any 
3ds damage that may result from this procedure if you use any of this software. Produce and store a full untouched NAND 
backup before this procedure.

Credits:
-profi200 for the correct twl decryption functions
-all contributors of the following repositories
https://gist.github.com/profi200/469f9fac6a394d23e8e1
https://github.com/codemonkey85/libCTRCrypto
https://github.com/Relys/3DS_Multi_Decryptor
https://github.com/jasinb/sha1