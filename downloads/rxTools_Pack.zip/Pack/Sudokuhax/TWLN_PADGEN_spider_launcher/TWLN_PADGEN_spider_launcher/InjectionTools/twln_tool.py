import os,sys

if len(sys.argv) < 2:
	print("Usage:\n")
	print("python twln_tool.py -d")
	print("for dump of and decryption twln.bin from NAND.bin or...\n")
	print("python twln_tool.py -e")
	print("to encrypt and inject twln.bin to NAND.bin\n")
	raw_input("press key to continue...")
	
MB=1024*1024
twlOffset=0x00012E00
twlSize=0x08FB5200

if sys.argv[1]=="-d":
	print("Opening NAND.bin, please wait...")
	fn=open("NAND.bin","rb")
	ft=open("temp","wb")
	
	fn.seek(twlOffset)
	ft.write(fn.read(twlSize))
	fn.close()
	ft.close()
	print("xoring..")
	os.system("xor.exe temp twln.xorpad")
	os.system("rename temp.out twln.img")
	os.system("rm temp")
	print("\nDumped twln partition from NAND.bin and decrypted it to output file twln.img")
	print("You may now open and modify it with Winimage, OSFMount,\n(or others) as a fat archive")
	
if sys.argv[1]=="-e":
	print("xoring...")
	os.system("xor.exe twln.img twln.xorpad")
	fn=open("NAND.bin","rb+")
	ft=open("twln.img.out","rb")
	
	print("writing to NAND.BIN...")
	fn.seek(twlOffset)
	fn.write(ft.read(twlSize))
	fn.close()
	ft.close()
	os.system("rm twln.img.out")
	print("\nEncrypted twln.img and injected it to NAND.BIN")
	print("You may now use GW or other means to restore it to your 3ds nand")
	print("Its a good idea to test this modded nand first by injecting it as an Emunand!")
	print("Nand modding is dangerous you know! You assume all responsibility if something goes wrong!")
	