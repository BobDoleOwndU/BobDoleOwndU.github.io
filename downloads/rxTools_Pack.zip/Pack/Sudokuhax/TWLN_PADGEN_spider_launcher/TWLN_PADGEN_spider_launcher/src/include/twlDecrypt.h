#include "types.h"

int NAND_decryptPartition();