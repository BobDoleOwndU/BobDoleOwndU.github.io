#include "types.h"
#include "CTRCrypto.h"
#include "FS.h"
#include "sha1.h"
#include "draw.h"
#include "libc.h"

u32 min(u32 a,u32 b){
	if(a < b)return a;
	else return b;
}

int NAND_decryptPartition()
{
  u32 length = 0;
  int result=0;
  u32 offset;
  u32 blockSize = 0;
  u32 hash[8];
  u32 bytes_written = 0;
  u32 i;
  AES_CTX ctx;
  uint8_t SDMC_file_handle[32] = {0x00};
  result = fileOpen(&SDMC_file_handle, L"sdmc:/twln.xorpad", 6);
	if(result != 0)
		return 1;

  u8 CID[16]={0};
  SHA1_Digest digest;

  memcpy(CID,(u32*)0x01FFCD84,16); //get nand CID from arm9 ITCM
  digest=SHA1_get (CID,16);       //sha1 hash over CID
  memcpy(hash,digest.digest,16);         //take first 16 bytes from hash digest. move it to ctr
  
  length = 0x08FB5200;
  //NAND_file_handle[4] = 0x00012E00; // This is like using seek
  offset = 0x00012E00;
  ctx.keyslot = 3;
  //HashCIDSha1((u8*)hash);

  length = (length + 0xf) & ~0xf; // Align to 16 bytes
  for(i=0; i<4; i++) ctx.CTR_IV_Nonce[i] = hash[i];
  
  ctx.CTR_IV_Nonce[0] += (offset>>4);
  ctx.CTR_IV_Nonce[4] = 0; // Reversed word order & little endian. [4] contains the AES engine settings for setting a CTR/IV/Nonce

  ctx.update = AES_CRYPT_SELECT_KEYSLOT; // Select keyslot for next en-/decryption

  // AES engine settings for the actual en-/decryption
  ctx.params = AES_FLUSH_READ_FIFO | AES_FLUSH_WRITE_FIFO | AES_BIT12 | AES_BIT13 | AES_MODE(AES_MODE_CTR2);
 
  memset((u8*)0x20400000, 0x00, 0x100000); // 1 MB
  offset = 0;

  for(i=0; i<=length / AES_BUFFERSIZE_MAX; i++)
  {
    blockSize = min(length - offset, AES_BUFFERSIZE_MAX);

    if(blockSize>0)
    {
      memset((u8*)0x20400000, 0x00, 0x100000); 
      AES_crypt(&ctx, (u32*)0x20400000, (u32*)0x20400000, blockSize);
      fileWrite(SDMC_file_handle, &bytes_written, (u32*)0x20400000, blockSize);

      offset += blockSize;
      ctx.CTR_IV_Nonce[0] += (blockSize>>4);
    }
    draw_fillrect(10, 50, 100, 8, BLACK);
    font_draw_stringf(10, 50, CYAN, "%i/143 MB", i); 
  }
  return 0;
}