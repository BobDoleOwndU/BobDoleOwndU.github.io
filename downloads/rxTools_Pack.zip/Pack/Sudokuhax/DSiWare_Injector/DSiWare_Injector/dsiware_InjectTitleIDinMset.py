
title_ID="4b513945"        # 8 characters or die.
filename="00000000.app"    # 8 + 3 characters or die. no reason to change me *most of the time*. updated versions wont be 00000000.app

######################################################################################################################################
#only change stuff above this line. no spaces!
######################################################################################################################################











if len(title_ID) != 8 or len(filename) != 12:
	print("Die!")
	exit()

highpath="00030004" # no reason to change me. probably
game="twln:/title/"+highpath+"/"+title_ID+"/content/"+filename+"\0"
save="twln:/title/"+highpath+"/"+title_ID+"/data/public.sav"+"\0"

gfind="/content/"
sfind="/data/"
gfind=gfind.encode("UTF-16")[2:]
sfind=sfind.encode("UTF-16")[2:]
f=open("MsetForBoss.dat","rb")
buf=f.read()
f.close()
goffset=buf.find(gfind)-58
soffset=buf.find(sfind)-58
print("\nFound game path offset: "+str(hex(goffset+58)))
print(  "Found save path offset: "+str(hex(soffset+58)))
print(  "If -1 then we didnt find it!\n")

game=game.encode("UTF-16")
save=save.encode("UTF-16")

f=open("MsetForBoss.dat","r+b")
f.seek(goffset)
f.write(game[2:])
f.seek(soffset)
f.write(save[2:])
f.close()

print(  "Patch complete.\n")