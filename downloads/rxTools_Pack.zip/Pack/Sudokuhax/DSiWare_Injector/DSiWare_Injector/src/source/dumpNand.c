#include "dumpNand.h"
#include "3dstypes.h"
#include "libc.h"
#include "FS.h"
#include "draw.h"
int BLOCK_SIZE=0;

int injectTwln(int destination)
{
	#define BUFFER_ADDR ((volatile uint8_t*)0x21000000)
	BLOCK_SIZE  =(16*1024);
	
	uint8_t  tIDHandle[128] = {0x00};
	uint8_t fileHandle[128] = {0x00};
	uint8_t nandHandle[128] = {0x00};
	uint32_t bytesWritten;
	uint32_t bytesRead;
	uint32_t result;
	
	memset(& tIDHandle, 0, 128);
	memset(&fileHandle, 0, 128);
	memset(&nandHandle, 0, 128);
	
	//twl injection sources for save and binary on sd card 
	if      (destination==90){
		DEBUG("Opening sdmc:/dsiware.sav ...");
		result = fileOpen(&fileHandle, L"sdmc:/dsiware.sav", 1);
		if(result != 0){ 
		    fileClose(&fileHandle);
			DEBUG("Could not find dsiware.sav! ...");
			return 2;
		}
	}
	else if (destination==50){
		DEBUG("Opening sdmc:/dsiware.nds ...");
		result = fileOpen(&fileHandle, L"sdmc:/dsiware.nds", 1);
		if(result != 0){ 
			fileClose(&fileHandle);
			DEBUG("Could not find dsiware! ...");
			return 3;
		}
	}
	
    
	//TWL NAND injection destinations for save and binary  
	if     (destination==90){
		DEBUG("Opening twln public.sav ...");
		result = fileOpen(&nandHandle, L"twln:/title/00030004/4b513945/data/public.sav", 6);
		
		if(result != 0){ 
			fileClose(&nandHandle);
			DEBUG("Could not open twl public.sav ...");
			return 4;
		}
	}
	else if(destination==50){
		DEBUG("Opening twln dsiware binary ...");
		result = fileOpen(&nandHandle, L"twln:/title/00030004/4b513945/content/00000000.app", 6);
		if(result != 0){ 
			DEBUG("Could not open twl dsiware binary ...");
			fileClose(&nandHandle);
			return 5;
		}
	}

	
	DEBUG("Injecting content to TWL NAND...");
	int y_pos=destination;
	
	uint32_t i = 0;
	do
	{
		fileRead(&fileHandle, &bytesRead, (void*)BUFFER_ADDR, BLOCK_SIZE);
		fileWrite(&nandHandle, &bytesWritten, (void*)BUFFER_ADDR, bytesRead);
		if(bytesWritten != bytesRead)
		{
			DEBUG("Error, TWLN NAND may be full.");
			fileClose(&nandHandle);
			fileClose(&fileHandle);
			return 1;
		}
		i += bytesRead;
		draw_fillrect(300, y_pos, 160, 8, BLACK);
		font_draw_stringf(300, y_pos, CYAN, "%dKBs", i/1024); 
	} while(bytesRead == BLOCK_SIZE);
	
	//draw_fillrect(10, 130, 160, 8, BLACK);
	DEBUG("Done!");
	
	fileClose(&nandHandle);
	fileClose(&fileHandle);
	return 0;
}

int dumpTwln(int destination)
{
	#define BUFFER_ADDR ((volatile uint8_t*)0x21000000)
	BLOCK_SIZE  =(16*1024);
	
	uint8_t  tIDHandle[128] = {0x00};
	uint8_t fileHandle[128] = {0x00};
	uint8_t nandHandle[128] = {0x00};
	uint32_t bytesWritten;
	uint32_t bytesRead;
	uint32_t result;
	
	memset(& tIDHandle, 0, 128);
	memset(&fileHandle, 0, 128);
	memset(&nandHandle, 0, 128);
	
	//twl dump destinations for save and binary on sd card 
	if      (destination==90){
		DEBUG("Opening sdmc:/dsiware.sav ...");
		result = fileOpen(&fileHandle, L"sdmc:/dsiware.sav", 6);
		if(result != 0){ 
		    fileClose(&fileHandle);
			DEBUG("Could not find dsiware.sav! ...");
			return 2;
		}
	}
	else if (destination==50){
		DEBUG("Opening sdmc:/dsiware.nds ...");
		result = fileOpen(&fileHandle, L"sdmc:/dsiware.nds", 6);
		if(result != 0){ 
			fileClose(&fileHandle);
			DEBUG("Could not find dsiware! ...");
			return 3;
		}
	}
	
    
	//TWL NAND dump sources for save and binary  
	if     (destination==90){
		DEBUG("Opening twln public.sav ...");
		result = fileOpen(&nandHandle, L"twln:/title/00030004/4b513945/data/public.sav", 1);
		
		if(result != 0){ 
			fileClose(&nandHandle);
			DEBUG("Could not open twl public.sav ...");
			return 4;
		}
	}
	else if(destination==50){
		DEBUG("Opening twln dsiware binary ...");
		result = fileOpen(&nandHandle, L"twln:/title/00030004/4b513945/content/00000000.app", 1);
		if(result != 0){ 
			DEBUG("Could not open twl dsiware binary ...");
			fileClose(&nandHandle);
			return 5;
		}
	}

	
	DEBUG("Dumping TWL content to SD card ...");
	int y_pos=destination;
	
	uint32_t i = 0;
	do
	{
		fileRead(&nandHandle, &bytesRead, (void*)BUFFER_ADDR, BLOCK_SIZE);
		fileWrite(&fileHandle, &bytesWritten, (void*)BUFFER_ADDR, bytesRead);
		if(bytesWritten != bytesRead)
		{
			DEBUG("Error, SD card may be full.");
			fileClose(&nandHandle);
			fileClose(&fileHandle);
			return 1;
		}
		i += bytesRead;
		draw_fillrect(300, y_pos, 160, 8, BLACK);
		font_draw_stringf(300, y_pos, CYAN, "%dKBs", i/1024); 
	} while(bytesRead == BLOCK_SIZE);
	
	//draw_fillrect(10, 130, 160, 8, BLACK);
	DEBUG("Done!");
	
	fileClose(&nandHandle);
	fileClose(&fileHandle);
	return 0;
}

uint32_t dumpNand(void)
{
	#define BUFFER_ADDR ((volatile uint8_t*)0x21000000)
	BLOCK_SIZE  =(2*1024*1024);
	
	uint8_t fileHandle[32] = {0x00};
	uint8_t nandHandle[32] = {0x00};
	uint32_t bytesWritten;
	uint32_t bytesRead;
	uint32_t result;
	
	memset(&fileHandle, 0, 32);
	memset(&nandHandle, 0, 32);
	
	DEBUG("Opening sdmc:/nand_dump.bin ...");
	result = fileOpen(&fileHandle, L"sdmc:/nand_dump.bin", 6);
	if(result != 0)
		return 1;
	
	DEBUG("Opening wnand:/ ...");
	result = fileOpen(&nandHandle, L"wnand:/", 1);
	if(result != 0)
	{
		fileClose(&fileHandle);
		return 1;
	}
	
	DEBUG("Dumping NAND...");
	
	uint32_t i = 0;
	do
	{
		fileRead(&nandHandle, &bytesRead, (void*)BUFFER_ADDR, BLOCK_SIZE);
		fileWrite(&fileHandle, &bytesWritten, (void*)BUFFER_ADDR, bytesRead);
		if(bytesWritten != bytesRead)
		{
			DEBUG("ERROR, SD card may be full.");
			fileClose(&nandHandle);
			fileClose(&fileHandle);
			return 1;
		}
		i += bytesRead;
		draw_fillrect(SCREEN_TOP_W-33, 1, 32, 8, BLACK);
		font_draw_stringf(SCREEN_TOP_W-33, 1, CYAN, "%i%%", i/(988807168/100)); //988,807,168 bytes is how big my NAND is. Just used for the percentage indicator.
	} while(bytesRead == BLOCK_SIZE);
	
	draw_fillrect(SCREEN_TOP_W-33, 1, 32, 8, BLACK);
	DEBUG("Done!");
	
	fileClose(&nandHandle);
	fileClose(&fileHandle);
	return 0;
}
