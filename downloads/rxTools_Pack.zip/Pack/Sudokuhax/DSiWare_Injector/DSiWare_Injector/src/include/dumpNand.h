#ifndef _DUMPNAND_H
#define _DUMPNAND_H

#include "3dstypes.h"

int injectTwln(int destination);
int dumpTwln(int destination);
uint32_t dumpNand(void); 

#endif
