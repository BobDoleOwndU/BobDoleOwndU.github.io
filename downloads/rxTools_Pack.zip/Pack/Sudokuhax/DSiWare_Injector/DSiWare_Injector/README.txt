DSiWare Injector - Sudokuhax 3D

This will inject the Sudokuhax DSimode homebrew kit in your 3DSs TWL NAND partition. 4.x firmwares only.

[1] Back up your 4.x 3DS NAND with Gateway 3.x.x firmware. Store NAND.bin safely. This only injects to TWL nand so your normal 3ds boot operation should be safe.
	However, your Twl (dsi) game titles can become damaged so its a good idea to export them to sd card via data management just in case. You alone are responsible for
	the consequences of running this and any hack software on your 3ds!
[2] Pick an installed dsiware titleID to inject to. Purchased sysnand running titles are the best because the hack will run on them without any addtional 3ds or ds hacks!
	Zelda Four Swords Usa is default title id on this distribution. injected titles run region free.
[3] Edit the title_ID of your chosen game on "dsiware_injectTitleIDinMset.py" with text editor. You can export dsi games and check sd card "private" for title ids. 
	Usually only the title id needs needs changing. if there has been an update of the title, the filename will likely change. (like ea sudoku!) 
[4] Run "dsiware_injectTitleIDinMset.py" with Python2 or Python3 and the new titleID will be injected to the msetforboss.dat file. this was done because reading
	the title sds from the sd on 3ds proved unpredictable. python method is more stable.
[5] Purchase EA Sudoku as you morally should do =^.^= But that is not the version you have to acquire for this hack. User caitsith has posted a repository of dsiware games on
	the hcs64 forums. Find "decrypted_titles_nomodcrypt.7z" on those forums. Delete all titles you don't own and keep the "SUDOKU-Electronic_Arts_Inc..nds"
	It has crc32 7e5ea8c7 and MD5 0184664c20cbe570549690fa4c254f11
[6] rename the sudoku game to dsiware.nds and place it and the supplied hacked save dsiware.sav and Msetforboss.dat on the root of your 3ds. 
	also boot.nds from http://filetrip.net/nds-downloads/applications/download-dsi-homebrew-channel-1-0-f25356.html 
	4 things total on root of 3ds sdmc card
	
	dsiware.nds 
	dsiware.sav
	MsetForBoss.dat
	boot.nds
	
[7] run MsetForBoss.dat and "DSiware Inject" to inject sudoku and the hack save; turn off 3ds; boot the game. the old banner should still be there so dont be suprised.
	Enjoy!


Sudokuhax 2D by
http://hackmii.com/2011/01/sudokuhax-release/

the 3ds injection stuff of course is not by yellows8 or team twiizers

injector based off of
https://github.com/Relys/3DS_Multi_Decryptor