cdn_firm.exe :
    Use this tool the first time you use rxTools.
    It will generate 'firmware.bin', a file necessary for the toolkit to work.
    Once it gets successfully generated, copy it in the root of your sdcard, along
    with 'rxTools.dat'.

msetdg.exe :
    Use this tool if you want to downgrade your System Settings app in your sysNand.
    This is useful becouse will make that entrypoint available on systems versions
    higher than 4.5.
    Once you've choosen your region, the 'msetdg.bin' file will be generated, and you'll
    have to copy it in the root of your sdcard.
    Once you downgraded the app, this file will automatically be deleted.

-Roxas75